let particles = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  frameRate(60);
  colorMode(LIGHTEST);
}

function draw() {
  if (mouseIsPressed){
  	let p = new Particle();
  	particles.push(p);
		for(let i = 0; i < particles.length; i++){
  		particles[i].update();
    	particles[i].show();
  	}
	}
}

class Particle{
  
  constructor(){
  this.x = mouseX;
	this.y = mouseY;
  this.vx = random(-1,1);
  this.vy = random(3,-3);
	this.alpha = 255;
  }
  
  update(){
    this.x += this.vx;
    this.y += this.vy;
    this.alpha -= 1.5;
  }
  
  show() {
    noStroke();
    fill(this.alpha,255-this.alpha,255-this.alpha);
    ellipse(this.x, this.y, random(5,10));
    
    
  }
  
  
}
  