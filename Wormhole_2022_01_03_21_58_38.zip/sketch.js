let warped;

function setup() {
	createCanvas(windowWidth, windowHeight);
	noStroke();
	rectMode(CENTER);
	wormhole = new Wormhole(width * 0.5, height * 0.5);
}

function draw() {
	background(0,0,0);
	wormhole.run();
}

class Wormhole {
	constructor(x, y) {
		this.startPos = createVector(x, y);
		this.d = 0;
	}

	update() {
		this.startPos.x = mouseX;
		this.startPos.y = mouseY;
	}

	display() {
		for (let x = 10; x < width; x += 7) {
			for (let y = 10; y < height; y += 7) {
				let n = noise(x * 0.005, y * 0.005, sin(frameCount) * 0.00009);
				if (mouseX <= 0 || mouseX >= width || mouseY <= 0 || mouseY >= height) {
					this.d = dist(width * 0.5, height * 0.5, x, y);
				} else {
					this.d = dist(this.startPos.x, this.startPos.y, x, y);
				}
				push();
				translate(mouseX, mouseY);
				rotate(TWO_PI * n * 400);
				scale(10 * (this.d / 33));
        fill(random(0,255),random(0,255),random(0,255));
        rect(10, 0, mouseX / width, mouseY / height)
				pop();
			}
		}
	}

	run() {
		this.update();
		this.display();
	}
}
