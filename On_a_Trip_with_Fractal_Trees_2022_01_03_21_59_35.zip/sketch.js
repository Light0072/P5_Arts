function setup(){
  createCanvas(windowWidth,windowHeight);
}

function draw(){
  background(51);
  stroke(255);
  translate(windowWidth/2,windowHeight);
 	branch(150)
}

function branch(len){
  strokeWeight(1);
  fill(random(0,255),random(0,255),random(0,255),random(0,255),random(0,255),random(0,255))
  curve(mouseX-150,mouseY-150, mouseX,mouseY+50, mouseX,mouseY-len,mouseX+150,mouseY+150)
  translate(0,-len);
  if (len>4){
    push();
    var angle = PI/4;
    rotate(angle);
    branch(len*0.7);
    pop();
    push();
    rotate(-angle);
    branch(len*0.7);
    pop();
  }  
}
