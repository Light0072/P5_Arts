let warped;   // for display
var mySound;  // song1
var mySound2; // song2

function preload()
{ 
  // load both songs into variables to play
  mySound = loadSound('UsedTo.mp3'); 
  mySound2 = loadSound('sahara_love.mp3');
}

function setup() {
  // set up a canvas for warped
  var can = createCanvas(windowWidth, windowHeight);
  can.mouseClicked(togglePlay);
  // obtain frequency straight from the sound file being played
  fft = new p5.FFT();
  noStroke();
  rectMode(CENTER);
  // noise uses a unique equation that gives you a sequential 
  // group of randomized numbers
  noiseDetail(3, 0.9);
  warped = new Warped(width * 0.5, height * 0.5);
  
}

function draw() {
  // store the analyzed frequency into an array
  var spectrum = fft.analyze();
  peak = (Math.pow(max(spectrum)/255.0,2)) * 255;
  // this next part allows for the background to be black
  // when playing song2 and white when playing song1
  if(mySound2.isPlaying() == true){
    if(peak == 255){background(0);}
    else if(peak >= 220){background((255-peak)/10); }
    else {background(peak+20);}
  }
  else{
    if(peak == 255){background(255);}
    else if(peak > 220){background(peak+20); }
    else {background((255-peak)/10);}
  }
  warped.run(); // allows the warped class to continue to update
}

class Warped {
	constructor(x, y) {
		this.startPos = createVector(x, y); // starting position
		this.d = 0;  // used for distance
        this.x = -100; // used for moving the eye of the wormhole
        this.y = -100; // used for moving the eye of the wormhole
	}

	update() {
      // if the peak is in a certain range the wormhole will move in 
      // certain direction. This applies ideas from the particle system in P5
      // if x and y exit the window then this will reset it back to the 
      // starting point.
      // this updates the values of this class
      if (this.x >= windowWidth) {this.x=0;}
      if (this.y >= windowHeight) {this.y=0;}
      if( peak == 255) {this.x += 5;this.y += 4;}
      else if( peak > 250) {this.x += 3;this.y += -4;}
      else if( peak > 245) {this.x += -3;this.y += 2;}
      else if( peak > 240) {this.x += 3;this.y += -2;}   
      else if( peak > 235) {this.x += -3;this.y += 0;}
      else if( peak > 230) {this.x += 3;this.y += 0;}   
      else{
        if(mySound.isPlaying() == true) {this.x += 1;this.y += 1;}
        else {this.x += -1;this.y += -1;}
      }
      this.startPos.x = this.x;
      this.startPos.y = this.x;
	}

	display() {
      // this allows for the visual aspect of this file
		for (let x = -100; x < width; x += 7) {
			for (let y = -100; y < height; y += 7) {
                // again noise is a spin off of random
				let n = noise(x * 0.005, y * 0.005, sin(frameCount) * 0.00009);
				// if the eye of the wormhole exits the window then this will reset it
                // and then it will resume drawing.
                if (this.x <= 0 ||  this.y <= 0) {
					this.d = dist(width * 0.5, height * 0.5, x, y);
                    this.x = width;
                    this.y = height;
				}  
                else if (this.x >= width || this.y >= height){
                    this.x = 0;
                    this.y = 0;
                    this.d = dist(width * 0.5, height * 0.5, x, y);
                }
                else {
					this.d = dist(this.startPos.x, this.startPos.y, x, y);
				}
				push();
                // this helps with positioning or each of the rectangles.\
				translate(width - this.x, height - this.y);
				rotate(TWO_PI * n * 400); // helps rotate them to give a 3Dish appeal
				scale(10 * (this.d / 33)); // this gives them a distance to keep apart
              
        // If the peak is in a certian range then all of the boxes 
        // will be in a certain color range.
        if( peak == 255){
          fill(random(0,255), random(0,255),random(0,255));
        }
        else if( peak > 250){
          fill(random(150,peak), 0, random(0,100));
        }   
        else if( peak > 245){
          fill(0, 0, random(150,peak));
        }  
        else if( peak > 240){
          fill(0, random(100,peak), random(150,peak));
        }   
        else if( peak > 235){
          fill(0, random(150,peak), 0);
        }  
        else if( peak > 230){
          fill(random(0,100), random(150,peak), 0);
        }   
        else if( peak > 225){
          fill(random(150,peak), 0, 0);
        } 
        else if( peak > 220){
          fill(peak, random(200,peak), random(200,peak));
        } 
        else if( peak > 215){
          fill(random(200,peak), peak, random(200,peak));
        } 
        else if( peak >= 210){
          fill(random(200,peak), random(200,peak), peak);
        }
        else{
          if(mySound.isPlaying() == true){
            fill(random(230,255), random(230,255), random(230,255));
          }
          else{
            fill(random(0,65), random(0,65), random(0,65));
          } 
        }
        
        // this helps draw the boxes in each quadrant relatively evenly
        if((this.x > windowWidth/2) && (this.y > windowHeight/2)){
          rect(10, 0, this.x / width, (this.y / height)/3);
        }
        else if((this.x > windowWidth/2) && (this.y < windowHeight/2)){
          rect(10, 0, this.x / width, (abs(height - this.y) / height)/3);
        }
        else if((this.x < windowWidth/2) && (this.y > windowHeight/2)){
          rect(10, 0, abs(width - this.x) / width, (this.y / height)/3);
        }
        else{
          rect(10, 0, abs(width - this.x) / width, (abs(height - this.y) / height)/3);
        }
				pop();
			}
		}
	}

	run() {
		this.update();
		this.display();
	}
}

function togglePlay()
{ 
  // this is used to determine which song is being played. 
  // also if one song is stopped then the other will continue to 
  // play from where it left off.
  if(mySound.isPlaying())
  {
    mySound.pause();
    mySound2.loop();
  }
  else
  {
    mySound.loop();
    mySound2.pause();

  }
}




